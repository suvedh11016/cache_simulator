import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class CacheSimulator {
    private int cacheSize;
    private int associativity;
    private int blockSize;
    private int numSets;
    private ArrayList<ArrayList<Integer>> cache;
    private int[] setMisses;
    private int[] setHits;
    private int totalMisses;
    private int totalHits;
    private ArrayList<String> addressList;

    public CacheSimulator(int cacheSize, int associativity, int blockSize) {
        this.cacheSize = cacheSize;
        this.associativity = associativity;
        this.blockSize = blockSize;

        
        this.numSets = (cacheSize * 1024) / (associativity * 64);
        int setIndexBits = (int) (Math.log(numSets) / Math.log(2));

        
        this.cache = new ArrayList<>();
        for (int i = 0; i < numSets; i++) {
            cache.add(new ArrayList<>());
        }
        this.setMisses = new int[numSets];
        this.setHits = new int[numSets];
    }

    public void simulate(String traceFilePath) {
        
        readTraceFile(traceFilePath);

        
        for (String address : addressList) {
            int setIndex = (Integer.parseInt(address.substring(2), 16) / blockSize) % numSets;
            int tag = Integer.parseInt(address.substring(2), 16) / (blockSize * numSets);

            ArrayList<Integer> set = cache.get(setIndex);
            boolean cacheHit = set.contains(tag);

            if (cacheHit) {
                setHits[setIndex]++;
                totalHits++;
               
                set.remove((Integer) tag);
                set.add(0, tag);
            } else {
                setMisses[setIndex]++;
                totalMisses++;
                
                if (set.size() >= associativity) {
                    set.remove(set.size() - 1); 
                }
                set.add(0, tag);
            }
        }

        
        System.out.println("Total Misses: " + totalMisses);
        System.out.println("Total Hits: " + totalHits);

        System.out.println("\nSet-wise Misses:");
        for (int i = 0; i < numSets; i++) {
            System.out.println("Set " + i + ": " + setMisses[i]);
        }

        System.out.println("\nSet-wise Hits:");
        for (int i = 0; i < numSets; i++) {
            System.out.println("Set " + i + ": " + setHits[i]);
        }
    }

    private void readTraceFile(String traceFilePath) {
        addressList = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(traceFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] addresses = line.trim().split(" ");
                addressList.addAll(Arrays.asList(addresses));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        
        if (args.length < 3) {
            System.out.println("Usage: java CacheSimulator <Cache Size> <Associativity> <Trace File>");
            return;
        }

        int cacheSize = Integer.parseInt(args[0]);
        int associativity = Integer.parseInt(args[1]);
        int blockSize = 64; 

        String traceFilePath = args[2];

        
        CacheSimulator simulator = new CacheSimulator(cacheSize, associativity, blockSize);

      
        simulator.simulate(traceFilePath);
    }
}

