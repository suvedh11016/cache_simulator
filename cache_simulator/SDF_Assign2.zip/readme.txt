# Cache Simulator

The Cache Simulator is a Java program that simulates the behavior of a cache memory system based on a provided trace file. It allows you to specify the cache size, associativity, and block size, and then simulates cache hits and misses for each memory address in the trace file.

## Features

- Configurable cache size, associativity, and block size.
- Support for LRU (Least Recently Used) replacement policy.
- Detailed statistics on cache hits and misses.
- Simulates cache behavior based on a provided trace file.

## Usage

1. Compile the Java source code: javac CacheSimulator.java
2. Run the compiled class with the required command line arguments:
java CacheSimulator <Cache Size> <Associativity> <Block Size> <Trace File>

- `<Cache Size>`: The size of the cache in kilobytes (KB).
- `<Associativity>`: The associativity of the cache (number of ways).
- `<Block Size>`: The size of each cache block in bytes.
- `<Trace File>`: The path to the trace file containing memory addresses.


3. The cache simulator will read the trace file and simulate cache hits and misses based on the provided cache configuration. Once the simulation is complete, it will display the total number of cache hits and misses, as well as set-wise hits and misses.

## Trace File Format

The trace file should contain memory addresses in hexadecimal format, with each address separated by a space. Here's an example format:

